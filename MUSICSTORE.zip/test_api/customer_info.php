<?php

require_once __DIR__.'/services/ServiceCustomer.php';

if (!isset($_GET['page'])) {
    $page = 1;
} else {
    $page = $_GET['page'];
}

$limit = 20;
$service = new CustomerService;
$customer=$service->GetCustomers($page);
$total_pages=$service->GetTotalCustomersCount($limit);
//$start = ($page-1) * $limit;
//$no = $page > 1 ? $start+1 : 1;

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/styles.css">
    <script src="js/jquery-3.5.1.js"></script>
    <script src="js/customer.js?s=8"></script>
    <title>Customer</title>
    <script>
      $(document).ready(function() {
        getAllCustomers();        
      });
    </script>
</head>
<body>
<div>
        <h2>Customer</h2>
	
        <a href="create_customer.php">Add a New Customer</a>
</div>
<div>
	<table class="table_id">
        <thead>
		    <tr>
                <th>Customer ID</th>
                <th>First Name</th>
                <th>Last Name</th>                   
                <th>Company</th>
                <th>Address</th>
                <th>City</th>
                <th>State</th>
                <th>Country</th>
                <th>Postal Code</th>
                <th>Phone</th>
                <th>Fax</th>
                <th>Email</th>
            </tr>
        </thead>
        <tbody>
        </tbody>
        <tfoot>
                
        </tfoot>

    </table>
    </div>
    <div>
            <ul class="pagination">
                    <li><a href="?page=1">First</a></li>

                    <?php for($p=1; $p < $total_pages; $p++){ ?>
                        
                        <li class="<?= $page == $p ? 'active' : ''; ?>" data-value="<?= $p?>"><a href="<?= '?page='.$p; ?>"><?= $p; ?></a></li>
                    <?php }?>
                    <li class="<?= $page == $total_pages ? 'active' : ''; ?>" data-value="<?= $total_pages?>"><a href="?page=<?= $total_pages; ?>"> Last</a></li>
                            
                        
                </ul>
    </div>
</body>
</html>