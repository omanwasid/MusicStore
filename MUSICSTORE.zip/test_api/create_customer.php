

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/styles.css">
    <script src="js/jquery-3.5.1.js"></script>
    <script src="js/customer.js"></script>
    <title>Document</title>
</head>
<body>

<div >
    <div >
        <div>
            <h2>Create A Customer</h2>
        </div>
        <div >
  
            <form method="POST">
                <div class="input-group">
                    <label for="fname">First Name</label>
                    <input type="text" name="fname" id="fname" class="create" require>
                </div>
                <div class="input-group">
                    <label for="lname">Last Name</label>
                    <input type="text" name="lname" id="lname" class="create" require>
                </div>
                <div class="input-group">
                    <label for="password">Password</label>
                    <input type="password" name="password" id="password" class="create" require>
                </div>
                <div class="input-group">
                    <label for="company">Company</label>
                    <input type="text" name="company" id="company" class="create">
                </div>
                <div class="input-group">
                    <label for="address">Address</label>
                    <input type="text" name="address" id="address" class="create">
                </div>
                <div class="input-group">
                    <label for="city">City</label>
                    <input type="text" name="city" id="city" class="create">
                </div>
                <div class="input-group">
                    <label for="state">State</label>
                    <input type="text" name="state" id="state" class="create">
                </div>
                <div class="input-group">
                    <label for="country">Country</label>
                    <input type="text" name="country" id="country" class="create">
                </div>
                <div class="input-group">
                    <label for="postalcode">Postal Code</label>
                    <input type="text" name="postalcode" id="postalcode" class="create" >
                </div>
                <div class="input-group" >
                    <label for="phone">Phone</label>
                    <input type="phone" name="phone" id="phone" class="create">
                </div>
                <div class="input-group">
                    <label for="fax">Fax</label>
                    <input type="text" name="fax" id="fax" class="create">
                </div>
                <div class="input-group">
                    <label for="email">Email</label>
                    <input type="email" name="email" id="email" class="create" require>
                </div>
                <div class="input-group">
                    <button type="submit" class="btn btn-info" id="addNewCustomer">Create A Customer</button>
                </div>

            </form>
        </div>
    </div>
</div>

</body>
</html>
