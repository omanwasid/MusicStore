
    //var page = $('#page').text();
   

function getAllCustomers() {
  var page = $('.active ').attr("data-value");
  if (page == undefined)
    page = 1;

    $.ajax({
      type: "GET",
      url: "api/customer.php?action=getAllCustomers&page=" + page,
      success: function (result) {
        var stringified = JSON.stringify(result);
        var data = JSON.parse(stringified);

        $('#tbody').empty();
        var tr = '';
        $.each(data, function (index, value) {
          tr = `
                <tr>
                <td>${value.CustomerId}</td>
                <td>${value.FirstName}</td>
                <td>${value.LastName}</td>
                <td>${value.Company}</td>
                <td>${value.Address}</td>
                <td>${value.City}</td>
                <td>${value.State}</td>
                <td>${value.Country}</td>
                <td>${value.postalCode}</td>
                <td>${value.Phone}</td>
                <td>${value.Fax}</td>
                <td>${value.Email}</td>
                <td><button class="edit" id ="${value.CustomerId}">Edit</button><button class="delete" id="${value.CustomerId}">Delete</button></td>               
                </tr>

                `;
          $('table').append($(tr));

        });
      }

    });

}

function getCustomer(editId) {
  
  $.ajax({
    type: "GET",
    url: "api/customer.php?action=getCustomerById&id=" + editId,
    success: function (result) {
      var stringified = JSON.stringify(result);
      var data = JSON.parse(stringified)
      var form = '';
      $("#fname").val(data.FirstName);
      $("#lname").val(data.LastName);
        $("#company").val(data.Company);
          $("#address").val(data.Address);
            $("#city").val(data.City);
              $("#state").val(data.State);
                $("#country").val(data.Country);
                  $("#postalcode").val(data.PostalCode);
                    $("#phone").val(data.Phone);
                      $("#fax").val(data.Fax);
                        $("#email").val(data.Email);
      
    }

  });
}

$(document).ready(function () {
    
    $(document).delegate('#addNewCustomer', 'click', function(event) {
        event.preventDefault();
        
        var fname = $('#fname').val();
        var lname = $('#lname').val();
        var password = $('#password').val();
        var company = $('#company').val();
        var address = $('#address').val();
        var city = $('#city').val();
        var state = $('#state').val();
        var country = $('#country').val();
        var postalcode = $('#postalcode').val();
        var phone = $('#phone').val();
        var fax = $('#fax').val();
        var email = $('#email').val();

        
        if(fname == null || fname == "") {
            alert("First Name is required");
            return;
        } else if(lname == null || lname == "") {
            alert("Last Name is required");
            return;
        } else if(password == null || password == "") {
            alert("Password is required");
            return;
        } else if(email == null || email == "") {
            alert("Email is required");
            return;
        }
        
        $.ajax({
            type: "POST",
            contentType: "application/json",
            url: "api/customer.php?action=create" ,
            data: JSON.stringify({'FirstName': fname, 'LastName': lname, 'Password': password, 'Company': company, 'Address': address, 'City': city, 'State': state, 'Country': country, 'PostalCode': postalcode, 'Phone': phone, 'Fax': fax, 'Email': email}),
            dataType:'json',
            cache: false,
            success: function(result) {
                if (result.statusCode==200){
                    alert('Customer added successfully');
                    location.reload();
                } else if (result.statusCode==201){
                    //alert (result);
                }
            },
            error: function(err) {
                alert('error');
                console.log("Error")
            }
        });
    });

    $(document).delegate('.edit', 'click', function(event) {
        event.preventDefault();
        var editId = $(this).attr('id');
      window.location.href = "edit_customer.php?editId=" + editId;
    });

            $(document).delegate('#editCustomer', 'click', function(event) {
                event.preventDefault();
        
                var fname = $('#fname').val();
                var lname = $('#lname').val();
                var company = $('#company').val();
                var address = $('#address').val();
                var city = $('#city').val();
                var state = $('#state').val();
                var country = $('#country').val();
                var postalcode = $('#postalcode').val();
                var phone = $('#phone').val();
                var fax = $('#fax').val();
                var email = $('#email').val();

        
             
                $.ajax({
                    type: "POST",
                    contentType: "application/json",
                    url: "api/customer.php?action=edit" ,
                    data: JSON.stringify({'FirstName': fname, 'LastName': lname, 'Company': company, 'Address': address, 'City': city, 'State': state, 'Country': country, 'PostalCode': postalcode, 'Phone': phone, 'Fax': fax, 'Email': email}),
                    dataType:'json',
                    cache: false,
                    success: function(result) {
                        if (result.statusCode==200){
                            alert('Customer Edited successfully');
                            location.reload();
                        } else if (result.statusCode==201){
                            //alert (result);
                        }
                    },
                    error: function(err) {
                        alert('error');
                        console.log("Error")
                    }
                });
            });

    $(document).delegate('.delete', 'click', function() { 
        if (confirm('Do you really want to delete record?')) {
            var id = $(this).attr('id');
            var parent = $(this).parent().parent();
            $.ajax({
                type: "GET",
                url: "API/customer.php?action=delete&id=" + id,
                cache: false,
                success: function() {
                    parent.fadeOut('slow', function() {
                        $(this).remove();
                    });
                    location.reload(true)
                },
                error: function() {
                    alert('Error deleting record');
                }
            });
        }
    });
    
    $('.addtrack').click(function () {    
        var id = $(this).attr('id');
        
          // AJEX request
          $.ajax({
            url: "api/invoice.php?action=add&id=" + id,
            type: 'GET',
            success: function (result) {
              var stringified = JSON.stringify(result);
              var data = JSON.parse(stringified);
              $('#cart').empty();
              data.forEach(showCart);          
              if (data.length > 0)
                addPurchaseButtn();
            }
          });
      });
    
      function addPurchaseButtn(){
        $('#cart').append($('<a style="color:black;" href="checkout.php">Checkout</a>'));
      }
    
      function removePurchaseButtn() {
    
      }
    
      function showCart(item) {
        $('#cart').append('<span>' + 'Name: '+item.value.name + ' qty: ' + item.value.qty + ' unit Price :' + item.value.unitPrice + ' total: ' + item.value.total + '</span><br>');
      }
    
      $('.removetrack').click(function () {    
        var id = $(this).attr('id');
    
        // AJEX request
        $.ajax({
          url: "api/invoice.php?action=remove&id=" + id,
          type: 'GET',
          success: function (result) {
            var stringified = JSON.stringify(result);
            var data = JSON.parse(stringified);
            $('#cart').empty();
            data.forEach(showCart);
            if (data.length > 0)
              addPurchaseButtn();
          }
        });
    
      });
    
});