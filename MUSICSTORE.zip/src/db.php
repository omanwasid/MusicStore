<?php

class Connect
{
  private static $dns ='mysql:host=chinookmusicstore.cfmoye6qgvv0.us-east-1.rds.amazonaws.com;dbname=chinook_abridged';
  private static $username = 'admin';
  private static $password = 'hellohello';
  private static $options= [];

  public static function GetConnection()
   {
        return new PDO(self::$dns,self::$username,self::$password, self::$options);
  }
}


?>