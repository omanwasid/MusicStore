"use strict";
$(document).ready(function() {

    // Cancel user sign up
    $("input#btnSignUpCancel").on("click", function() { 
        window.location.replace('login.php') 
    });    
});