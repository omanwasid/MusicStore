$(document).ready(function () {


  $.ajaxSetup({
    headers: { "Authorization": "Basic " + btoa(username + ":" + password) }
  });

  $('.deletecustomer').click(function() {
        // Deleted ID
        var deletedId = $(this).attr('id');

        var confirmAlert = confirm("Are you sure?");
        if (confirmAlert == true) {
            // AJEX request
            $.ajax({
                url:"api/customer.php?action=delete&id="+ deletedId,
                type : 'GET',                
              success: function (result) {
                if (result['message'] == 'success') {
                    $('#row' + deletedId).remove();
                    } else {
                        alert('Invalid ID.');
                    }
                }
            });
        }
  });


  $('.addtrack').click(function () {    
    var id = $(this).attr('id');
    
      // AJEX request
      $.ajax({
        url: "api/invoice.php?action=add&id=" + id,
        type: 'GET',
        success: function (result) {
          var stringified = JSON.stringify(result);
          var data = JSON.parse(stringified);
          $('#cart').empty();
          data.forEach(showCart);          
          if (data.length > 0)
            addPurchaseButtn();
        }
      });
  });

  function addPurchaseButtn(){
    $('#cart').append($('<a style="color:black;" href="checkout.php">Checkout</a>'));
  }

  function removePurchaseButtn() {

  }

  function showCart(item) {
    $('#cart').append('<span>' + 'Name: '+item.value.name + ' qty: ' + item.value.qty + ' unit Price :' + item.value.unitPrice + ' total: ' + item.value.total + '</span><br>');
  }

  $('.removetrack').click(function () {    
    var id = $(this).attr('id');

    // AJEX request
    $.ajax({
      url: "api/invoice.php?action=remove&id=" + id,
      type: 'GET',
      success: function (result) {
        var stringified = JSON.stringify(result);
        var data = JSON.parse(stringified);
        $('#cart').empty();
        data.forEach(showCart);
        if (data.length > 0)
          addPurchaseButtn();
      }
    });

  });



  function addPurchaseButtn(){
    $('#cart').append($('<a style="color:black;" href="checkout.php">Checkout</a>'));
  }

  function removePurchaseButtn() {

  }

  function showCart(item) {
    $('#cart').append('<span>' + 'Name: '+item.value.name + ' qty: ' + item.value.qty + ' unit Price :' + item.value.unitPrice + ' total: ' + item.value.total + '</span><br>');
  }




});